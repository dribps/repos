<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'benchmarks'   => 'Benchmarks',
	'post_data'    => 'Dati postati',
	'no_post'      => 'Non ci sono dati postati',
	'session_data' => 'Dati di sessione',
	'no_session'   => 'Non ci sono dati di sessione',
	'queries'      => 'Query al database',
	'no_queries'   => 'Non ci sono query al database',
	'no_database'  => 'Database non caricato',
	'cookie_data'  => 'Dati del cookie',
	'no_cookie'    => 'I dati del cookie non sono stati trovati',
);
