<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group'   => 'Группа %s не определена вашей конфигурацией.',
	'requires_mcrypt'   => 'Для использования библиотеки Encrypt необходимо включить расширение "mcrypt" в конфигурации PHP.',
	'no_encryption_key' => 'Для использования библиотеки Encrypt необходимо задать ключ шифрования в конфигурационном файле.'
);
