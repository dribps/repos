<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang['query_methods_not_allowed'] = 'Query methods kunnen niet gebruikt worden via ORM';