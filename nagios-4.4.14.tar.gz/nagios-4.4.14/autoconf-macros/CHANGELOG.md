1.0.1
-----
 * Fix bug determining inetd,xinetd if neither are running (Bryan Heden)

1.0.0
-----
 * Initial Release (John Frickson)